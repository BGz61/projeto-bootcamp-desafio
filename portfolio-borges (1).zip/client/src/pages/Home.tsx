import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Github, Linkedin, Mail, ExternalLink, Code2, Zap, Layout } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";

/**
 * Design Philosophy: Minimalist Modern with Subtle Gradients
 * - Clean dark theme with cyan accents
 * - Smooth animations and transitions
 * - Professional and accessible layout
 * - Focus on showcasing projects and skills
 */

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: "easeOut" }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.3,
    },
  },
};

export default function Home() {
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);

  const skills = [
    { icon: Code2, name: "Front-End", items: ["React", "TypeScript", "Tailwind CSS"] },
    { icon: Layout, name: "Design", items: ["Responsivo", "UI/UX", "Figma"] },
    { icon: Zap, name: "Performance", items: ["Otimização", "SEO", "Acessibilidade"] },
  ];

  const projects = [
    {
      id: 1,
      title: "Plataforma E-commerce",
      description: "Site de e-commerce moderno com React e Tailwind CSS",
      tags: ["React", "Tailwind", "JavaScript"],
      link: "#",
      github: "#",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663604241095/DGArSmuqFJjywxdhpivtY4/projects-bg-cdXhHoG2Lb3mEsLxTQWzgH.webp"
    },
    {
      id: 2,
      title: "Aplicativo de Gerenciamento de Tarefas",
      description: "Gerenciamento colaborativo de tarefas com atualizações em tempo real",
      tags: ["React", "Firebase", "TypeScript"],
      link: "#",
      github: "#",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663604241095/DGArSmuqFJjywxdhpivtY4/skills-pattern-WVCmzmdmphRrRgzebwkKpN.webp"
    },
    {
      id: 3,
      title: "Site de Portfólio",
      description: "Portfólio pessoal com design moderno e animações",
      tags: ["Next.js", "Tailwind", "Framer Motion"],
      link: "#",
      github: "#",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663604241095/DGArSmuqFJjywxdhpivtY4/about-section-bg-b2cDgsXufyzhuaHyWBCb4V.webp"
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent"
          >
            Borges
          </motion.div>
          <div className="flex gap-6">
            <a href="#about" className="text-sm hover:text-primary transition-colors">Sobre</a>
            <a href="#skills" className="text-sm hover:text-primary transition-colors">Habilidades</a>
            <a href="#projects" className="text-sm hover:text-primary transition-colors">Projetos</a>
            <a href="#contact" className="text-sm hover:text-primary transition-colors">Contato</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center pt-20 pb-20 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663604241095/DGArSmuqFJjywxdhpivtY4/hero-background-84gojpzubaaiSjJ7vTcpaD.webp')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/50 to-background" />

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="container max-w-4xl mx-auto px-4 text-center relative z-10"
        >
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-6xl md:text-7xl font-bold mb-6 tracking-tight"
          >
            Gabriel Borges
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-2xl md:text-3xl text-primary font-light mb-8"
          >
            Desenvolvedor Front-End
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed"
          >
            Criando experiências web modernas, responsivas e acessíveis. Especializado em React, TypeScript e design de interfaces intuitivas.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              asChild
            >
              <a href="#projects">Ver Meus Projetos</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary text-primary hover:bg-primary/10"
              asChild
            >
              <a href="#contact">Entre em Contato</a>
            </Button>
          </motion.div>
        </motion.div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-card/50">
        <div className="container max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-4xl font-bold mb-12">Sobre Mim</h2>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6 text-muted-foreground">
                <p className="text-lg leading-relaxed">
                  Sou um desenvolvedor Front-End apaixonado por criar interfaces intuitivas e performáticas. Com experiência em React e tecnologias modernas, transformo ideias em soluções web de alta qualidade.
                </p>
                <p className="text-lg leading-relaxed">
                  Meu foco está em escrever código limpo, acessível e bem estruturado, sempre pensando na melhor experiência do usuário.
                </p>
                <div className="flex gap-4 pt-4">
                  <a href="https://www.linkedin.com/in/gabriel-borges-8443a640b/?isSelfProfile=true" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary/80 transition-colors">
                    <Linkedin size={24} />
                  </a>
                  <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary/80 transition-colors">
                    <Github size={24} />
                  </a>
                  <a href="mailto:gabrielllborgesss146@gmail.com" className="text-primary hover:text-primary/80 transition-colors">
                    <Mail size={24} />
                  </a>
                </div>
              </div>

              <div
                className="rounded-lg overflow-hidden h-80 bg-gradient-to-br from-primary/20 to-primary/5"
                style={{
                  backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663604241095/DGArSmuqFJjywxdhpivtY4/about-section-bg-b2cDgsXufyzhuaHyWBCb4V.webp')",
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20">
        <div className="container max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-12">Habilidades</h2>

            <motion.div
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid md:grid-cols-3 gap-6"
            >
              {skills.map((skill, index) => {
                const Icon = skill.icon;
                return (
                  <motion.div
                    key={index}
                    variants={fadeInUp}
                    className="p-6 rounded-lg bg-card border border-border hover:border-primary transition-all duration-300 hover:shadow-lg hover:shadow-primary/10"
                  >
                    <Icon className="w-8 h-8 text-primary mb-4" />
                    <h3 className="text-xl font-semibold mb-4">{skill.name}</h3>
                    <div className="flex flex-wrap gap-2">
                      {skill.items.map((item, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 text-sm bg-primary/10 text-primary rounded-full"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-card/50">
        <div className="container max-w-5xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-12">Projetos</h2>

            <motion.div
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {projects.map((project) => (
                <motion.div
                  key={project.id}
                  variants={fadeInUp}
                  onMouseEnter={() => setHoveredProject(project.id)}
                  onMouseLeave={() => setHoveredProject(null)}
                  className="group relative rounded-lg overflow-hidden bg-card border border-border hover:border-primary transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
                >
                  <div className="relative h-48 overflow-hidden bg-gradient-to-br from-primary/20 to-primary/5">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                    <p className="text-muted-foreground text-sm mb-4">{project.description}</p>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag, i) => (
                        <span
                          key={i}
                          className="px-2 py-1 text-xs bg-primary/10 text-primary rounded"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    <div className="flex gap-3 pt-4 border-t border-border">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="flex-1 text-primary hover:text-primary hover:bg-primary/10"
                        asChild
                      >
                        <a href={project.link} target="_blank" rel="noopener noreferrer">
                          <ExternalLink size={16} className="mr-2" />
                          Demo
                        </a>
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="flex-1 text-primary hover:text-primary hover:bg-primary/10"
                        asChild
                      >
                        <a href={project.github} target="_blank" rel="noopener noreferrer">
                          <Github size={16} className="mr-2" />
                          Código
                        </a>
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center space-y-8"
          >
            <h2 className="text-4xl font-bold">Vamos Trabalhar Juntos?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Estou sempre aberto a novas oportunidades e projetos interessantes. Sinta-se livre para entrar em contato!
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
                asChild
              >
                <a href="mailto:gabrielllborgesss146@gmail.com">
                  <Mail className="mr-2" size={20} />
                  Enviar Email
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary/10"
                asChild
              >
                <a href="https://wa.me/5561992192765" target="_blank" rel="noopener noreferrer">
                  WhatsApp
                </a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 bg-card/50">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
              <p className="text-muted-foreground">© 2025 Gabriel Borges. Todos os direitos reservados.</p>
            </div>
            <div className="flex gap-6">
              <a href="https://www.linkedin.com/in/gabriel-borges-8443a640b/?isSelfProfile=true" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                <Github size={20} />
              </a>
              <a href="mailto:gabrielllborgesss146@gmail.com" className="text-muted-foreground hover:text-primary transition-colors">
                <Mail size={20} />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
